SHOPSPHERE — BLIND YAML TROUBLESHOOTING CHALLENGE
=================================================

This folder contains Kubernetes manifests for a simulated retail platform running on Amazon EKS with EKS Auto Mode.

Participant instructions
------------------------
1. Use a dedicated, disposable, non-production EKS cluster.
2. Read the manifests and inspect the target cluster before applying them.
3. Apply one challenge file at a time. Do not apply the entire directory in one command.
4. Some resources may be rejected at API admission. Others may be accepted but fail during scheduling, startup, health checks, service routing, autoscaling, storage, network access or rollout.
5. Identify the issues independently. No issue descriptions or solution hints are embedded in the manifests.
6. Capture evidence before making changes, then submit corrected YAML and proof of recovery.
7. Do not force-delete Pods, delete persistent data, or modify shared cluster-wide infrastructure as a shortcut.

Suggested setup
---------------
kubectl apply -f 00-namespace.yaml
kubectl get nodes -o wide
kubectl get storageclass
kubectl get ingressclass
kubectl api-resources | grep -Ei 'nodepool|nodeclass|nodeclaim'

Apply separately
----------------
kubectl apply --dry-run=server -f 01-workload.yaml
kubectl apply -f 01-workload.yaml
kubectl get all -n shop-capstone
kubectl get events -n shop-capstone --sort-by=.lastTimestamp

Repeat for each file, observing and recording the behavior before proceeding.

Evidence collection
-------------------
kubectl get pods -n shop-capstone -o wide
kubectl describe pod <pod-name> -n shop-capstone
kubectl logs <pod-name> -n shop-capstone --all-containers
kubectl logs <pod-name> -n shop-capstone --all-containers --previous
kubectl get deploy,rs,svc,endpointslices,pvc,hpa,pdb -n shop-capstone
kubectl get events -n shop-capstone --sort-by=.lastTimestamp
kubectl top pods -n shop-capstone
kubectl top nodes

EKS Auto Mode notes
-------------------
- Do not install a separate upstream Karpenter controller in an EKS Auto Mode cluster.
- Check the NodePool / NodeClass APIs and supported fields on the actual cluster version.
- Do not assume upstream Karpenter CRDs are interchangeable with EKS Auto Mode resources.
- StorageClass names vary. Inspect the cluster's available StorageClasses before selecting a correction.
- NetworkPolicy enforcement depends on the cluster networking implementation and configuration.
- Metrics-based HPA requires the metrics API / metrics-server or the relevant custom metrics adapter.
- Ingress requires a supported ingress controller / class in the cluster.

Mandatory submission for every challenge
----------------------------------------
A. Screenshot of the initial error or unexpected behavior.
B. Screenshot of diagnostic evidence (events, describe output, logs, metrics or controller status).
C. Corrected YAML or Git diff.
D. Screenshot showing healthy final state.
E. RCA: impact, timeline, root cause, contributing factors, evidence, remediation and prevention.
F. SLA/SLO evidence: measured availability, error rate, p95 latency and recovery time where applicable. Include Grafana or load-test screenshots and state the measurement window.

Cleanup
-------
After collecting evidence and ensuring there is no data to retain:
kubectl delete namespace shop-capstone

Check for cloud resources created by Services / storage and verify they are removed. Use only disposable lab resources.
